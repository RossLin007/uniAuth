


这是一个 统一登入的平台。
为各类服务（笔记，aichat等等，很多应用） 提供统一的登入认证。

需要提供前端 SDK，后端 SDK，以及

提供手机注册登录，
使用腾讯的短信服务。
腾讯sdk https://cloud.tencent.com/document/product/382/43193
腾讯短信发送 https://cloud.tencent.com/document/product/382/55981
https://github.com/TencentCloud/tencentcloud-sdk-nodejs


应用名	
默认应用
SDKAppID	
1400837083
SDKAppID是短信应用的唯一标识，调用短信API接口时，需要提供该参数。
App Key
f2e1467513df69aa74e50157f2ddbd51


技术栈：

- nodejs
- typescript
- supabase postgres

database url
https://rohbpofzvzphisdunjlf.supabase.co

anon key
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJvaGJwb2Z6dnpwaGlzZHVuamxmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUwNTA3MTcsImV4cCI6MjA4MDYyNjcxN30.uBvionTwptTXZf7oE-SCOqVOPpq8EgkcuxshwzPb9Jw





Request URL
https://rag.55387.xyz/api/documents/get-upload-url
Request Method
POST
Status Code
500 Internal Server Error
Remote Address
74.125.195.121:443

{"fileName":"202510_merged.md","contentType":"text/markdown","storeName":"fileSearchStores/xd-xpuck5t7wh46","displayName":"202510_merged.md","memo":"{\"source\":\"\",\"background\":\"\",\"usage\":\"\",\"dataFlow\":{\"from\":\"\",\"to\":\"\"}}"}

{
  "success": false,
  "error": "Permission 'iam.serviceAccounts.signBlob' denied on resource (or it may not exist)."
}